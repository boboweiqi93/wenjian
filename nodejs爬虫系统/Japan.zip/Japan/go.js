/**
 * Created by mgtcl on 2017/3/31.
 */
var main=require("./main.js");
var CronJob = require('cron').CronJob;
var http = require("http");
var fs = require("fs");


new CronJob('10 * * * * *', function() {
    main();
}, null, true, 'America/Los_Angeles');



function onRequest(request, response){
//     console.log("Request received.");
    response.writeHead(200,{"Content-Type":'text/plain','charset':'utf-8','Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'PUT,POST,GET,DELETE,OPTIONS'});//可以解决跨域的请求
    str=fs.readFileSync('data.txt');
    response.write(str);
    response.end();
}

http.createServer(onRequest).listen(8887);

console.log("Server has started.port on 8887\n");
// console.log("test data: "+str.toString());